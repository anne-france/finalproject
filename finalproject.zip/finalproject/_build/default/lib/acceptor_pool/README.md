acceptor_pool
=============

A tcp acceptor pool library

Build
-----

    $ rebar3 compile
