Plumtree
=======================================================

[![Build Status](https://travis-ci.org/lasp-lang/plumtree.svg?branch=master)](https://travis-ci.org/lasp-lang/plumtree)
