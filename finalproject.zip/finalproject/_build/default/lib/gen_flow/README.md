Generic Flow Abstraction
=======================================================

[![Build Status](https://travis-ci.org/lasp-lang/gen_flow.svg?branch=master)](https://travis-ci.org/lasp-lang/gen_flow)
