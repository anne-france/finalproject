Types
=======================================================

[![Build Status](https://travis-ci.org/lasp-lang/types.svg?branch=master)](https://travis-ci.org/lasp-lang/types)

## Types

Reference implementation for Conflict-free Replicated Data Types in
Erlang.
