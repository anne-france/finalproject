Time Compatibility Library
=======================================================

[![Build Status](https://travis-ci.org/lasp-lang/time_compat.svg?branch=master)](https://travis-ci.org/lasp-lang/time_compat)
