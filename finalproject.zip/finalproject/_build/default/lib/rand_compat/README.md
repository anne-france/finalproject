Random Compatibility Library
=======================================================

[![Build Status](https://travis-ci.org/lasp-lang/rand_compat.svg?branch=master)](https://travis-ci.org/lasp-lang/rand_compat)
